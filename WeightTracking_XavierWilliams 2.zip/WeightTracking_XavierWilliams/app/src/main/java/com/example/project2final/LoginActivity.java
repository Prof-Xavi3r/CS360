package com.example.project2final;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.editTextTextPassword);
        loginButton = findViewById(R.id.loginButton);

        // Set click listener for the login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the username and password entered by the user
                String username = usernameInput.getText().toString();
                String password = passwordInput.getText().toString();

                // Perform authentication (replace this with your actual authentication logic)
                boolean isAuthenticated = authenticateUser(username, password);

                // Check if authentication was successful
                if (isAuthenticated) {
                    // Display a success message
                    Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                    // Navigate to the next activity
                    // Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    // startActivity(intent);
                } else {
                    // Display an error message
                    Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to perform user authentication (replace this with your actual authentication logic)
    private boolean authenticateUser(String username, String password) {
        // Dummy authentication logic (replace this with your actual authentication logic)
        return username.equals("admin") && password.equals("password");
    }
}
